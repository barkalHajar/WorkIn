import random
import string

from django.contrib.auth.models import User
from django.contrib.auth.models import AbstractUser
from django.contrib.auth.models import AbstractBaseUser
from django.contrib.auth.models import Group
from django.contrib.contenttypes.models import ContentType
from datetime import datetime

from WorkInApp import models as WorkInApp_models


def random_string(length=10):
    # Create a random string of length length
    letters = string.ascii_lowercase
    return "".join(random.choice(letters) for i in range(length))


def create_User(**kwargs):
    defaults = {
        "username": "%s_username" % random_string(5),
        "email": "%s_username@tempurl.com" % random_string(5),
    }
    defaults.update(**kwargs)
    return User.objects.create(**defaults)


def create_AbstractUser(**kwargs):
    defaults = {
        "username": "%s_username" % random_string(5),
        "email": "%s_username@tempurl.com" % random_string(5),
    }
    defaults.update(**kwargs)
    return AbstractUser.objects.create(**defaults)


def create_AbstractBaseUser(**kwargs):
    defaults = {
        "username": "%s_username" % random_string(5),
        "email": "%s_username@tempurl.com" % random_string(5),
    }
    defaults.update(**kwargs)
    return AbstractBaseUser.objects.create(**defaults)


def create_Group(**kwargs):
    defaults = {
        "name": "%s_group" % random_string(5),
    }
    defaults.update(**kwargs)
    return Group.objects.create(**defaults)


def create_ContentType(**kwargs):
    defaults = {
    }
    defaults.update(**kwargs)
    return ContentType.objects.create(**defaults)


def create_WorkInApp_Contrat(**kwargs):
    defaults = {}
    defaults["Statut"] = ""
    defaults["Description"] = ""
    defaults["Date_de_creation"] = datetime.now()
    defaults.update(**kwargs)
    return WorkInApp_models.Contrat.objects.create(**defaults)
def create_WorkInApp_Employeur(**kwargs):
    defaults = {}
    defaults["Raison_social"] = ""
    defaults["Adresse"] = ""
    defaults["CA"] = ""
    defaults["Denomination_social"] = ""
    defaults["Email"] = ""
    defaults["Secteur_d_activite"] = ""
    defaults["Tel"] = ""
    defaults.update(**kwargs)
    return WorkInApp_models.Employeur.objects.create(**defaults)
def create_WorkInApp_Employee(**kwargs):
    defaults = {}
    defaults["Date_de_naissance"] = datetime.now()
    defaults["Nom"] = ""
    defaults["Prenom"] = ""
    defaults["Email"] = ""
    defaults["Solde"] = ""
    defaults["Adresse"] = ""
    defaults["Tel"] = ""
    defaults.update(**kwargs)
    return WorkInApp_models.Employee.objects.create(**defaults)
def create_WorkInApp_Facture(**kwargs):
    defaults = {}
    defaults["Quantite"] = ""
    defaults["Statut"] = ""
    defaults["TVA"] = ""
    defaults["Montant"] = ""
    defaults.update(**kwargs)
    return WorkInApp_models.Facture.objects.create(**defaults)
def create_WorkInApp_Mission(**kwargs):
    defaults = {}
    defaults["Nbr_employee"] = ""
    defaults["Description"] = ""
    defaults["Date_de_creation_mission"] = datetime.now()
    defaults["Statut"] = ""
    defaults["Lieu_de_mission"] = ""
    defaults["Fin_de_mission"] = datetime.now()
    defaults["Prix_heure"] = ""
    defaults["Quantite_heure"] = ""
    defaults["Date_de_debut_de_mission"] = datetime.now()
    defaults["contract_support"] = ""
    defaults.update(**kwargs)
    return WorkInApp_models.Mission.objects.create(**defaults)

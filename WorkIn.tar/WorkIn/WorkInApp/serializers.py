from rest_framework import serializers

from . import models


class ContratSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.Contrat
        fields = [
            "ID_Contrat",
            "Statut",
            "created",
            "Description",
            "last_updated",
            "Date_de_creation",
        ]

class EmployeurSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.Employeur
        fields = [
            "Raison_social",
            "Adresse",
            "CA",
            "created",
            "Denomination_social",
            "Email",
            "ID_Employeur",
            "Secteur_d_activite",
            "Tel",
            "last_updated",
        ]

class EmployeeSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.Employee
        fields = [
            "Date_de_naissance",
            "last_updated",
            "Nom",
            "Prenom",
            "Email",
            "Solde",
            "Adresse",
            "Tel",
            "ID_Employee",
            "created",
        ]

class FactureSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.Facture
        fields = [
            "created",
            "ID_Facture",
            "Quantite",
            "Statut",
            "last_updated",
            "TVA",
            "Montant",
        ]

class MissionSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.Mission
        fields = [
            "Nbr_employee",
            "Description",
            "Date_de_creation_mission",
            "Statut",
            "Lieu_de_mission",
            "last_updated",
            "Fin_de_mission",
            "Prix_heure",
            "Quantite_heure",
            "Date_de_debut_de_mission",
            "created",
            "contract_support",
            "ID_Mission",
        ]

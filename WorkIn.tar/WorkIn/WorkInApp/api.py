from rest_framework import viewsets, permissions

from . import serializers
from . import models


class ContratViewSet(viewsets.ModelViewSet):
    """ViewSet for the Contrat class"""

    queryset = models.Contrat.objects.all()
    serializer_class = serializers.ContratSerializer
    permission_classes = [permissions.IsAuthenticated]


class EmployeurViewSet(viewsets.ModelViewSet):
    """ViewSet for the Employeur class"""

    queryset = models.Employeur.objects.all()
    serializer_class = serializers.EmployeurSerializer
    permission_classes = [permissions.IsAuthenticated]


class EmployeeViewSet(viewsets.ModelViewSet):
    """ViewSet for the Employee class"""

    queryset = models.Employee.objects.all()
    serializer_class = serializers.EmployeeSerializer
    permission_classes = [permissions.IsAuthenticated]


class FactureViewSet(viewsets.ModelViewSet):
    """ViewSet for the Facture class"""

    queryset = models.Facture.objects.all()
    serializer_class = serializers.FactureSerializer
    permission_classes = [permissions.IsAuthenticated]


class MissionViewSet(viewsets.ModelViewSet):
    """ViewSet for the Mission class"""

    queryset = models.Mission.objects.all()
    serializer_class = serializers.MissionSerializer
    permission_classes = [permissions.IsAuthenticated]

from django.views import generic
from django.urls import reverse_lazy
from . import models
from . import forms


class ContratListView(generic.ListView):
    model = models.Contrat
    form_class = forms.ContratForm


class ContratCreateView(generic.CreateView):
    model = models.Contrat
    form_class = forms.ContratForm


class ContratDetailView(generic.DetailView):
    model = models.Contrat
    form_class = forms.ContratForm
    pk_url_kwarg = "ID_Contrat"


class ContratUpdateView(generic.UpdateView):
    model = models.Contrat
    form_class = forms.ContratForm
    pk_url_kwarg = "ID_Contrat"


class ContratDeleteView(generic.DeleteView):
    model = models.Contrat
    success_url = reverse_lazy("WorkInApp_Contrat_list")


class EmployeurListView(generic.ListView):
    model = models.Employeur
    form_class = forms.EmployeurForm


class EmployeurCreateView(generic.CreateView):
    model = models.Employeur
    form_class = forms.EmployeurForm


class EmployeurDetailView(generic.DetailView):
    model = models.Employeur
    form_class = forms.EmployeurForm
    pk_url_kwarg = "ID_Employeur"


class EmployeurUpdateView(generic.UpdateView):
    model = models.Employeur
    form_class = forms.EmployeurForm
    pk_url_kwarg = "ID_Employeur"


class EmployeurDeleteView(generic.DeleteView):
    model = models.Employeur
    success_url = reverse_lazy("WorkInApp_Employeur_list")


class EmployeeListView(generic.ListView):
    model = models.Employee
    form_class = forms.EmployeeForm


class EmployeeCreateView(generic.CreateView):
    model = models.Employee
    form_class = forms.EmployeeForm


class EmployeeDetailView(generic.DetailView):
    model = models.Employee
    form_class = forms.EmployeeForm
    pk_url_kwarg = "ID_Employee"


class EmployeeUpdateView(generic.UpdateView):
    model = models.Employee
    form_class = forms.EmployeeForm
    pk_url_kwarg = "ID_Employee"


class EmployeeDeleteView(generic.DeleteView):
    model = models.Employee
    success_url = reverse_lazy("WorkInApp_Employee_list")


class FactureListView(generic.ListView):
    model = models.Facture
    form_class = forms.FactureForm


class FactureCreateView(generic.CreateView):
    model = models.Facture
    form_class = forms.FactureForm


class FactureDetailView(generic.DetailView):
    model = models.Facture
    form_class = forms.FactureForm
    pk_url_kwarg = "ID_Facture"


class FactureUpdateView(generic.UpdateView):
    model = models.Facture
    form_class = forms.FactureForm
    pk_url_kwarg = "ID_Facture"


class FactureDeleteView(generic.DeleteView):
    model = models.Facture
    success_url = reverse_lazy("WorkInApp_Facture_list")


class MissionListView(generic.ListView):
    model = models.Mission
    form_class = forms.MissionForm


class MissionCreateView(generic.CreateView):
    model = models.Mission
    form_class = forms.MissionForm


class MissionDetailView(generic.DetailView):
    model = models.Mission
    form_class = forms.MissionForm
    pk_url_kwarg = "ID_Mission"


class MissionUpdateView(generic.UpdateView):
    model = models.Mission
    form_class = forms.MissionForm
    pk_url_kwarg = "ID_Mission"


class MissionDeleteView(generic.DeleteView):
    model = models.Mission
    success_url = reverse_lazy("WorkInApp_Mission_list")

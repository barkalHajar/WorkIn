import pytest
import test_helpers

from django.urls import reverse


pytestmark = [pytest.mark.django_db]


def tests_Contrat_list_view(client):
    instance1 = test_helpers.create_WorkInApp_Contrat()
    instance2 = test_helpers.create_WorkInApp_Contrat()
    url = reverse("WorkInApp_Contrat_list")
    response = client.get(url)
    assert response.status_code == 200
    assert str(instance1) in response.content.decode("utf-8")
    assert str(instance2) in response.content.decode("utf-8")


def tests_Contrat_create_view(client):
    url = reverse("WorkInApp_Contrat_create")
    data = {
        "Statut": true,
        "Description": "text",
        "Date_de_creation": datetime.now(),
    }
    response = client.post(url, data)
    assert response.status_code == 302


def tests_Contrat_detail_view(client):
    instance = test_helpers.create_WorkInApp_Contrat()
    url = reverse("WorkInApp_Contrat_detail", args=[instance.ID_Contrat, ])
    response = client.get(url)
    assert response.status_code == 200
    assert str(instance) in response.content.decode("utf-8")


def tests_Contrat_update_view(client):
    instance = test_helpers.create_WorkInApp_Contrat()
    url = reverse("WorkInApp_Contrat_update", args=[instance.ID_Contrat, ])
    data = {
        "Statut": true,
        "Description": "text",
        "Date_de_creation": datetime.now(),
    }
    response = client.post(url, data)
    assert response.status_code == 302


def tests_Employeur_list_view(client):
    instance1 = test_helpers.create_WorkInApp_Employeur()
    instance2 = test_helpers.create_WorkInApp_Employeur()
    url = reverse("WorkInApp_Employeur_list")
    response = client.get(url)
    assert response.status_code == 200
    assert str(instance1) in response.content.decode("utf-8")
    assert str(instance2) in response.content.decode("utf-8")


def tests_Employeur_create_view(client):
    url = reverse("WorkInApp_Employeur_create")
    data = {
        "Raison_social": "text",
        "Adresse": "text",
        "CA": 1.0f,
        "Denomination_social": "text",
        "Email": "text",
        "Secteur_d_activite": "text",
        "Tel": "text",
    }
    response = client.post(url, data)
    assert response.status_code == 302


def tests_Employeur_detail_view(client):
    instance = test_helpers.create_WorkInApp_Employeur()
    url = reverse("WorkInApp_Employeur_detail", args=[instance.ID_Employeur, ])
    response = client.get(url)
    assert response.status_code == 200
    assert str(instance) in response.content.decode("utf-8")


def tests_Employeur_update_view(client):
    instance = test_helpers.create_WorkInApp_Employeur()
    url = reverse("WorkInApp_Employeur_update", args=[instance.ID_Employeur, ])
    data = {
        "Raison_social": "text",
        "Adresse": "text",
        "CA": 1.0f,
        "Denomination_social": "text",
        "Email": "text",
        "Secteur_d_activite": "text",
        "Tel": "text",
    }
    response = client.post(url, data)
    assert response.status_code == 302


def tests_Employee_list_view(client):
    instance1 = test_helpers.create_WorkInApp_Employee()
    instance2 = test_helpers.create_WorkInApp_Employee()
    url = reverse("WorkInApp_Employee_list")
    response = client.get(url)
    assert response.status_code == 200
    assert str(instance1) in response.content.decode("utf-8")
    assert str(instance2) in response.content.decode("utf-8")


def tests_Employee_create_view(client):
    url = reverse("WorkInApp_Employee_create")
    data = {
        "Date_de_naissance": datetime.now(),
        "Nom": "text",
        "Prenom": "text",
        "Email": "text",
        "Solde": 1.0f,
        "Adresse": "text",
        "Tel": "text",
    }
    response = client.post(url, data)
    assert response.status_code == 302


def tests_Employee_detail_view(client):
    instance = test_helpers.create_WorkInApp_Employee()
    url = reverse("WorkInApp_Employee_detail", args=[instance.ID_Employee, ])
    response = client.get(url)
    assert response.status_code == 200
    assert str(instance) in response.content.decode("utf-8")


def tests_Employee_update_view(client):
    instance = test_helpers.create_WorkInApp_Employee()
    url = reverse("WorkInApp_Employee_update", args=[instance.ID_Employee, ])
    data = {
        "Date_de_naissance": datetime.now(),
        "Nom": "text",
        "Prenom": "text",
        "Email": "text",
        "Solde": 1.0f,
        "Adresse": "text",
        "Tel": "text",
    }
    response = client.post(url, data)
    assert response.status_code == 302


def tests_Facture_list_view(client):
    instance1 = test_helpers.create_WorkInApp_Facture()
    instance2 = test_helpers.create_WorkInApp_Facture()
    url = reverse("WorkInApp_Facture_list")
    response = client.get(url)
    assert response.status_code == 200
    assert str(instance1) in response.content.decode("utf-8")
    assert str(instance2) in response.content.decode("utf-8")


def tests_Facture_create_view(client):
    url = reverse("WorkInApp_Facture_create")
    data = {
        "Quantite": 1.0f,
        "Statut": true,
        "TVA": 1.0f,
        "Montant": 1.0f,
    }
    response = client.post(url, data)
    assert response.status_code == 302


def tests_Facture_detail_view(client):
    instance = test_helpers.create_WorkInApp_Facture()
    url = reverse("WorkInApp_Facture_detail", args=[instance.ID_Facture, ])
    response = client.get(url)
    assert response.status_code == 200
    assert str(instance) in response.content.decode("utf-8")


def tests_Facture_update_view(client):
    instance = test_helpers.create_WorkInApp_Facture()
    url = reverse("WorkInApp_Facture_update", args=[instance.ID_Facture, ])
    data = {
        "Quantite": 1.0f,
        "Statut": true,
        "TVA": 1.0f,
        "Montant": 1.0f,
    }
    response = client.post(url, data)
    assert response.status_code == 302


def tests_Mission_list_view(client):
    instance1 = test_helpers.create_WorkInApp_Mission()
    instance2 = test_helpers.create_WorkInApp_Mission()
    url = reverse("WorkInApp_Mission_list")
    response = client.get(url)
    assert response.status_code == 200
    assert str(instance1) in response.content.decode("utf-8")
    assert str(instance2) in response.content.decode("utf-8")


def tests_Mission_create_view(client):
    url = reverse("WorkInApp_Mission_create")
    data = {
        "Nbr_employee": 1,
        "Description": "text",
        "Date_de_creation_mission": datetime.now(),
        "Statut": true,
        "Lieu_de_mission": "text",
        "Fin_de_mission": datetime.now(),
        "Prix_heure": 1.0f,
        "Quantite_heure": 1.0f,
        "Date_de_debut_de_mission": datetime.now(),
        "contract_support": "text",
    }
    response = client.post(url, data)
    assert response.status_code == 302


def tests_Mission_detail_view(client):
    instance = test_helpers.create_WorkInApp_Mission()
    url = reverse("WorkInApp_Mission_detail", args=[instance.ID_Mission, ])
    response = client.get(url)
    assert response.status_code == 200
    assert str(instance) in response.content.decode("utf-8")


def tests_Mission_update_view(client):
    instance = test_helpers.create_WorkInApp_Mission()
    url = reverse("WorkInApp_Mission_update", args=[instance.ID_Mission, ])
    data = {
        "Nbr_employee": 1,
        "Description": "text",
        "Date_de_creation_mission": datetime.now(),
        "Statut": true,
        "Lieu_de_mission": "text",
        "Fin_de_mission": datetime.now(),
        "Prix_heure": 1.0f,
        "Quantite_heure": 1.0f,
        "Date_de_debut_de_mission": datetime.now(),
        "contract_support": "text",
    }
    response = client.post(url, data)
    assert response.status_code == 302
